# JornadaMicrosoft
[FORMAÇÃO MS-DEV] 
TURMA 02/2022

- Aprendendo a programar com C#
- Backend e serviços na nuvem da Microsoft Azure
- Plataforma Microsoft e Projeto Final


LINK DO PROJETO FINAL:

