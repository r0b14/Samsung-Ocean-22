using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EJOGOS.Views.Equipe
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
